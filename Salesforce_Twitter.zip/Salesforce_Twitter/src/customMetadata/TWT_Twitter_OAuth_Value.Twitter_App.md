<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Twitter App</label>
    <values>
        <field>Consumer_Key__c</field>
        <value xsi:type="xsd:string">075125CheRnRTrVh503ebmw4Z</value>
    </values>
    <values>
        <field>Consumer_Secret__c</field>
        <value xsi:type="xsd:string">nahSO19XXPAOMPkWRE3RpfMT4rEQPASVRH3xu46oYlCxcMK53Z</value>
    </values>
</CustomMetadata>
